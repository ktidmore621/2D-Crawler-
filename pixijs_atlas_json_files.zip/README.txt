PixiJS 8 atlas files for the three survivor characters.

What is included
- 7 atlas JSON files per character: idle, walk, run, attack, roll, hurt, death
- 1 manifest JSON per character

Assumptions these atlases use
- Frame size: 48x64
- Row order in each PNG: down, left, right, up
- File naming:
  male_idle.png
  male_walk.png
  male_run.png
  male_attack.png
  male_roll.png
  male_hurt.png
  male_death.png
  female_idle.png
  ...
  androgynous_death.png

Important
These atlas files assume your PNG sheets are true grid-aligned sheets at the sizes below:
- idle:   192x256
- walk:   288x256
- run:    288x256
- attack: 288x256
- roll:   288x256
- hurt:   144x256
- death:  288x256

If your generated images are not exactly those sizes, the JSON coordinates will not line up correctly.
